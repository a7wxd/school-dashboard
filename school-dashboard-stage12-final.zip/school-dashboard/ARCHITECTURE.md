# ARCHITECTURE.md

> Read this file at the start of every session. It reflects the current, approved architecture of the School Management Dashboard. Update it at the end of every session if the architecture changes.

**Last updated:** Stage 1 (Foundation) — initial version incorporating the v2 spec (multi-teacher, dashboards, 9–1 grade system, report workflow, backups, soft-delete).

---

## 1. Technology Stack

Unchanged from the approved plan:

- Next.js 14 (App Router) + TypeScript
- Tailwind CSS + shadcn/ui
- PostgreSQL + Prisma ORM
- Auth.js (credentials provider, bcrypt hashing)
- Recharts (charts), @react-pdf/renderer (PDFs), Resend/SMTP (email)
- TanStack Query (data fetching/caching), React Hook Form + Zod (forms/validation)
- Inngest (background jobs — term-end reports, scheduled backup checks)
- Vercel (app hosting) + Neon/Supabase (managed Postgres)

## 2. User Management & Roles

- **Roles:** `ADMIN` (exactly one initially, but the schema does not hard-limit this), `TEACHER` (many).
- Teachers are managed entirely from **Settings → Users** by the Administrator: create, edit, deactivate, reactivate. Deactivated teachers cannot log in but their historical actions (grades entered, reports sent) remain intact and correctly attributed — accounts are never hard-deleted.
- Each `User` record tracks `lastLoginAt`, updated on every successful login.
- **Teacher ↔ Subject** is many-to-many via a join table (`TeacherSubject`), since a teacher may teach several subjects and a subject may have several teachers (e.g. parallel classes). This also gives us a natural place to later add "class"/"set" granularity without another schema rewrite.
- Every mutating action (grade entered, comment saved, student added/removed, report generated/edited/approved/sent, settings changed) writes an `ActivityLog` row referencing the acting `User`. This powers both the audit trail and the "Recent activity" dashboard widgets.

## 3. Database Schema (v2)

```
User
├── id
├── fullName
├── email (unique, used for login)
├── passwordHash
├── role                 → enum: ADMIN | TEACHER
├── isActive             → boolean (deactivate/reactivate, never hard delete)
├── createdAt
├── lastLoginAt

TeacherSubject (join table: many-to-many)
├── id
├── teacherId → User
├── subjectId → Subject
├── (unique constraint on teacherId+subjectId)

Subject
├── id
├── name
├── code
├── appliesToYearGroups   → array, editable in Settings
├── isActive              → boolean (admin can remove; soft-disable, not delete,
│                            so historical grade records keep referential integrity)

Student
├── id
├── studentId             → auto-generated unique code
├── firstName / lastName
├── yearGroup
├── dateOfBirth
├── satsReadingScore / satsMathsScore
├── senStatus / senNotes
├── causeForConcern (boolean + reason)
├── overallAttendance     → denormalised %, recalculated on write
├── deletedAt             → nullable timestamp (SOFT DELETE — hidden from UI,
│                            data + reports remain intact, restorable by admin)
├── createdById → User
├── createdAt / updatedAt

ParentContact
├── id, studentId → Student, name, relationship, email, phone, isPrimaryContact

Enrolment (Student × Subject × AcademicYear)
├── id
├── studentId → Student
├── subjectId → Subject
├── academicYearId → AcademicYear
├── teacherId → User (nullable — auto-enrolment on student creation happens before
│                a specific class teacher is assigned; assigned later via
│                Subjects/Settings, Stage 5/11)

TermRecord (Enrolment × Term) — UPDATED grade fields, 9–1 GCSE scale only
├── id
├── enrolmentId → Enrolment
├── term                 → TERM_1 | TERM_2 | TERM_3
├── currentGrade         → int 1–9
├── workingAtGrade       → int 1–9
├── predictedGrade       → int 1–9   (system-derived, see §5; admin can override)
├── targetGrade          → int 1–9
├── previousGrade        → int 1–9 (nullable — carried from prior term automatically)
├── differenceFromTarget → int (computed: currentGrade - targetGrade, stored + recalculated on save)
├── teacherAssessment    → text
├── behaviourRating, attitudeToLearning, progressRating, attendancePercent
├── teacherComment, additionalNotes
├── enteredById → User
├── lastEditedAt

AcademicYear
├── id, label, term1Start/End, term2Start/End, term3Start/End, isCurrent

Report — UPDATED workflow states
├── id
├── studentId → Student
├── type                 → TERM | END_OF_YEAR
├── term (nullable for end-of-year)
├── academicYearId
├── status               → DRAFT | PREVIEW | EDITED | APPROVED | SENT
├── contentSnapshot      → JSONB (frozen data, immutable once APPROVED)
├── generatedAt / approvedAt / sentAt
├── generatedById → User
├── approvedById → User (nullable until approved)

ReportEmailLog
├── id, reportId → Report, parentContactId → ParentContact, sentById → User,
├── sentAt, deliveryStatus (SENT|DELIVERED|FAILED|BOUNCED), providerMessageId

NoteFromTeacher
├── id, studentId → Student, authorId → User, body, createdAt

ActivityLog  (NEW — powers audit trail + dashboard "recent activity")
├── id
├── userId → User
├── action              → enum-like string, e.g. "STUDENT_CREATED", "GRADE_UPDATED",
│                          "REPORT_SENT", "TEACHER_DEACTIVATED"
├── entityType / entityId   (polymorphic reference, e.g. "Student" / studentId)
├── metadata            → JSONB (before/after values where relevant)
├── createdAt

SchoolSettings (singleton)
├── id, schoolName, logoUrl, primaryColour, secondaryColour,
├── emailProviderConfig (JSONB), reportTemplateConfig (JSONB)

BackupLog (NEW — supports the backup requirement)
├── id
├── startedAt / completedAt
├── status              → RUNNING | SUCCESS | FAILED
├── fileLocation
├── sizeBytes
├── triggeredBy         → "SCHEDULED" | userId (manual trigger, future admin feature)
```

**Data-integrity rules enforced at the schema/application layer:**
- Every `Student` requires: name, year group, at least one `Enrolment`, and the current `AcademicYear`'s three `TermRecord`s are created automatically for each enrolment (Term 1/2/3 always exist — no partial term structures).
- `Report.contentSnapshot` is a frozen copy of the data at generation time, so historical reports never change even if a student's live record is later edited — this is also what makes soft-deleted students' past reports remain fully intact.
- Deleting a `Subject` is disallowed if any `Enrolment` references it; admins instead toggle `isActive = false`, which removes it from new-enrolment pickers system-wide immediately, without breaking history.
- No hard deletes anywhere in the schema except rows that were never meant to persist (e.g. expired sessions). Students, subjects, and users are all soft-deactivated.

## 4. Permissions

Unchanged in mechanism from the original plan (`lib/permissions.ts` permission map), extended with the new capabilities:

```
STUDENT_VIEW                                              → ADMIN, TEACHER
STUDENT_CREATE, STUDENT_DELETE (soft), STUDENT_RESTORE   → ADMIN
USER_MANAGE (create/edit/deactivate/reactivate teachers) → ADMIN
SUBJECT_MANAGE                                            → ADMIN
GRADE_ENTER, COMMENT_ENTER                                → ADMIN, TEACHER
REPORT_GENERATE, REPORT_EDIT                              → ADMIN, TEACHER
REPORT_APPROVE, REPORT_SEND                               → ADMIN, TEACHER
PREDICTED_GRADE_OVERRIDE                                  → ADMIN only
SETTINGS_MANAGE                                           → ADMIN
BACKUP_VIEW                                               → ADMIN
```

Every API route re-validates server-side regardless of client-side hiding.

## 5. Grade & Progress Calculation Rules

- **Scale:** all grades (`currentGrade`, `workingAtGrade`, `predictedGrade`, `targetGrade`, `previousGrade`) are integers 1–9 (GCSE 9–1 scale) — enforced by a Zod schema and a Postgres check constraint.
- **Difference from target:** `differenceFromTarget = currentGrade - targetGrade`, recalculated server-side on every save (never trusted from the client).
- **Progress classification:** derived from `differenceFromTarget`:
  - `> 0` → Above Target
  - `= 0` → On Target
  - `< 0` → Below Target
- **Average grade (per student):** mean of `currentGrade` across all subjects, across all `TermRecord`s created so far in the current academic year (recomputed on demand for profile/analytics views, not stored, to avoid staleness).
- **Predicted grade logic:** calculated server-side from (a) the trend across previous terms' `currentGrade` values, (b) the teacher's `teacherAssessment` text/rating input, and (c) term progression weighting (later terms weighted more heavily). This value populates `predictedGrade` automatically after each term-record save.
  - **Predicted grade can only be manually overridden by an Administrator.** Teachers see it as read-only. The override is logged in `ActivityLog` with before/after values.

## 6. Reports Workflow

State machine: `DRAFT → PREVIEW → EDITED (optional loop) → APPROVED → SENT`

- **Generate Report** creates a `DRAFT` with a `contentSnapshot` built from current data.
- **Preview** renders that snapshot as a read-only PDF-style view.
- **Edit** allows teacher edits to comments/targets/praise/concerns; each edit updates the snapshot and sets status to `EDITED`.
- **Approve** locks the snapshot (immutable from this point) and sets status to `APPROVED`. Only after approval can it be sent.
- **Send to Parent(s)** delivers the PDF, creates `ReportEmailLog` entries, sets status to `SENT`.

**Fixed report section order (enforced by the PDF template, not left to per-report customisation):**
1. Student Header (name, ID, year group, academic year + term)
2. Attendance Summary
3. Behaviour Summary
4. Overall Academic Summary (average grade, overall progress)
5. Subject Breakdown (table: current/working-at/predicted/target/previous/difference per subject)
6. Teacher Comments
7. Praise
8. Causes for Concern
9. Targets for Improvement
10. Signature (teacher name + generated date/time)

**Formatting rules enforced in the shared `ReportPdfDocument` component:**
- One shared font family, spacing scale and margin set for every report — no per-report style drift.
- School logo + brand colours pulled live from `SchoolSettings`.
- Missing data renders as `"N/A"` — sections are never removed, so every report has a predictable, identical structure for parents and staff.
- Subject grade tables use fixed column widths and `react-pdf`'s page-break-aware `<View>`s so tables never split awkwardly across a page boundary.

## 7. Dashboards

**Administrator dashboard** (server-computed aggregates, cached briefly via TanStack Query):
Total students, total teachers, reports pending sending (status `APPROVED` and not yet `SENT`), attendance overview (school-wide %), behaviour overview, recent activity feed (from `ActivityLog`), recently added students, Quick Add Student action, global search, current academic term, current date.

**Teacher dashboard:**
Assigned classes (derived from `TeacherSubject` + `Enrolment`), students needing attention (flagged `causeForConcern` or below-target progress within their classes), pending grade-entry tasks (enrolments missing a `TermRecord` for the current term), draft reports (status `DRAFT`/`EDITED` authored by them), recent activity (their own recent `ActivityLog` entries).

## 8. Backups

- Automated daily full-database backup (managed by the hosting provider's native backup feature where possible — e.g. Neon/Supabase point-in-time recovery — supplemented by a scheduled export job logged in `BackupLog`).
- Backups must be restorable on demand; the `BackupLog` table and a future **Settings → Backups** screen give the admin visibility into backup history and status, with restore initiated via provider tooling initially, and a self-service "restore" button once the provider integration is wired up.

## 9. Soft Delete (Students)

- `Student.deletedAt` set on removal; all list/search queries filter `deletedAt: null` by default.
- Soft-deleted students remain fully queryable by ID for report/audit purposes, so historical reports (`Report.contentSnapshot`) are unaffected.
- Admin can restore (`deletedAt = null`) from a "Deleted Students" view (Settings, or a filter within Students).

## 10. Non-functional requirements

- All server-side mutations validated with Zod before touching the database.
- No orphaned records: cascading rules defined in Prisma (e.g. deleting a `Subject` is blocked, not cascaded, if `Enrolment`s exist; deleting an `AcademicYear` is disallowed once it contains data).
- Every list page paginated server-side for performance at scale (500+ students).
- Accessibility: all interactive components from shadcn/ui (Radix-based), keyboard-navigable, proper ARIA labelling, colour contrast checked against WCAG AA (relevant since Settings allows custom brand colours — we validate contrast and warn if a chosen colour fails AA against white/dark text).

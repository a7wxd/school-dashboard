# School Management Dashboard

A modern school management system for a UK secondary school (Years 7–11), built to feel like a premium commercial MIS (in the spirit of Arbor, Bromcom, SIMS, Satchel One).

## Getting started

```bash
npm install
cp .env.example .env      # then fill in DATABASE_URL etc.
npm run prisma:migrate    # creates the database schema
npm run prisma:seed       # loads demo admin/teachers/students
npm run dev
```

Demo login (from the seed script):
- **Admin:** `admin@example-school.uk` / `ChangeMe123!`
- **Teacher:** `s.whitfield@example-school.uk` / `Teacher123!` (or the other two seeded teachers)

⚠️ Change these credentials before any real deployment.

## Project documentation

Read these three files at the start of every working session — they're kept up to date at the end of each one:

- [`ARCHITECTURE.md`](./ARCHITECTURE.md) — current system design, schema, and rules
- [`PROJECT_PROGRESS.md`](./PROJECT_PROGRESS.md) — what's built, what's next, spec-compliance checklist
- [`CHANGELOG.md`](./CHANGELOG.md) — session-by-session change history

## Stage 1 (Foundation) — what's included

- Next.js 14 (App Router) + TypeScript project scaffold
- Tailwind CSS + design-token theming system (school-brandable via CSS variables)
- Full Prisma schema (v2) — users, teacher↔subject many-to-many, students, subjects, enrolments, term records, reports (with approval workflow), email logs, activity log, settings, backup log
- Seed script with an admin, three teachers, the correct Y7–9/Y10–11 subject lists, and demo students with Term 1 grade data
- Shared grade-calculation logic (`src/lib/grades.ts`) implementing the approved calculation rules (difference from target, average grade, predicted grade)
- Permissions map (`src/lib/permissions.ts`) ready for Stage 2 wiring

## Stage 2 (Authentication & Permissions) — what's included

- Auth.js v5 credentials-provider login, 8-hour JWT sessions, bcrypt password checks
- `middleware.ts` protecting every route; `requirePermission()` as the real server-side security boundary on every API route
- `usePermissions()` client hook for role-aware UI
- A distinctive login screen that also live-previews the brand colours from `SchoolSettings`
- Teacher management API foundation (`/api/teachers`, `/api/teachers/[id]`) — create, edit, deactivate, reactivate, many-to-many subject assignment, fully activity-logged

## Stage 3 (App Shell & Dashboards) — what's included

- Collapsible `Sidebar`, `Topbar` with global student search and user menu, reusable `PageHeader`
- Role-aware `/dashboard` landing page — separate Admin and Teacher views covering every widget from the spec (totals, pending reports, attendance/behaviour overview, recent activity, assigned classes, students needing attention, pending grade tasks, draft reports)
- Placeholder pages for every remaining sidebar section so navigation is fully wired

## Stage 4 (Students Module) — what's included

- `/students` — year-group tabs, search, filters (subject, SEN status, cause for concern)
- `/students/new` — Add Student flow with auto-generated Student ID and automatic subject enrolment + Term 1–3 scaffolding
- `/students/[studentId]` — profile page with current-term grades, SEN notes, parent contacts, and admin-only Remove Student (soft delete, confirmation dialog)

⚠️ Schema changed this stage (`Enrolment.teacherId` is now nullable) — run `npm run prisma:migrate` again after pulling.

## Stage 5 (Subjects & Bulk Grade Entry) — what's included

- `/subjects` — subject card grid; `/subjects/[subjectId]` — detail page with add/remove teacher assignment (`TeacherAssignmentPanel`, via the `TeacherSubject` many-to-many — no per-class restriction, any assigned teacher can grade any year group of that subject)
- `/subjects/[subjectId]/[yearGroup]` — the real bulk grade entry grid: editable Current/Working At/Target grades, Behaviour, Attitude, Comment, with a live Progress badge, autosaving per row
- `PATCH /api/term-records/[id]` recalculates Difference from Target and Progress server-side on every save, and auto-derives Predicted Grade from the term trend unless an admin explicitly overrides it

## Stage 6 (Student Profile, Full Depth) — what's included

- `/students/[studentId]` is now a tabbed profile: Overview, Academic History, Progress, Attendance & Behaviour, SEN & Notes, Parents
- Interactive Recharts charts — grade trend over time (overall + per-subject), attendance by term
- Full multi-term academic history grid and a per-subject Behaviour/Attitude table across all three terms

## Stage 7, Part A (Report Generation, Preview & Edit) — what's included

- `/reports` — list of every generated report, with a Generate Report dialog (pick student + term)
- `/reports/[id]` — in-browser preview following the exact fixed section order from the spec (Student Header → Attendance → Behaviour → Academic Summary → Subject Breakdown → Teacher Comments → Praise → Causes for Concern → Targets → Signature), with `N/A` fallback for missing data
- Praise / Causes for Concern / Targets are editable until a report is approved (Part B)

⚠️ No Approve/Send buttons or PDF file yet — that's Part B.

## Stage 7, Part B (Approve, Send & PDF Export) — what's included

- `ReportPdfDocument` — the actual downloadable PDF (`@react-pdf/renderer`), matching the in-browser preview exactly; `GET /api/reports/[id]/pdf` streams it
- Approve locks the report snapshot; Send moves it to `SENT` and logs one `ReportEmailLog` row per parent contact

⚠️ **Send is a workflow/history stub, not real email delivery** — no provider is wired up until Stage 8. Don't rely on it for actually reaching parents yet.

## Stage 8 (Email Delivery & Parents Section) — what's included

- Real email delivery via Resend (`src/lib/email.ts`) — Send now actually emails the PDF to every parent contact on file, with a real per-recipient `SENT`/`FAILED` status shown immediately and on both the report and parent pages
- `/parents` — searchable contact list; `/parents/[parentId]` — contact details, linked student, ready-to-send reports, and full communication history

⚠️ Set `RESEND_API_KEY` and `EMAIL_FROM_DOMAIN` in `.env` for Send to actually work — without them, sends fail with a clear error rather than silently pretending to succeed. The `EMAIL_FROM_DOMAIN` also needs to be a domain verified in your Resend account.

## Stage 9 (End-of-Year Report) — what's included

- Generate an end-of-year report from the same `/reports` dialog (Report Type: "End of year report") — no separate page or layout, it reuses `ReportPreview`/`ReportPdfDocument` with adapted labels and a Term 1/2/3 subject trend table
- `buildEndOfYearSnapshot()` aggregates the whole academic year: per-subject grade trend, whole-year attendance/behaviour, and a year-progress summary (start average → end average, improvement)

## Stage 10 (Analytics Section) — what's included

- `/analytics` — six school-wide chart widgets: grade trend over time, predicted GCSE outcomes (Y10/11), attendance by term and year group, behaviour summary, progress over time, and subject performance
- All charts read directly from the same `TermRecord` data the grade grid, student profiles, and reports use — no separate analytics pipeline to keep in sync

## Stage 11, Part A (Settings — Nav, School, Academic Year, Users) — what's included

- Role-aware Settings sub-navigation — admins see everything, teachers see only My Profile
- `/settings/school` — name, logo, brand colours with live preview
- `/settings/academic-year` — add years, edit term dates, set which one is current
- `/settings/users` — the admin UI for the teacher-account API that's existed since Stage 2: create, view, deactivate/reactivate
- `/settings/profile` — read-only account info for any user

## Stage 11, Part B (Subjects, Report Templates, Backups & Deleted Students) — what's included

- `/settings/subjects` — add/edit subjects, remove via an active/inactive toggle (no hard delete, so historical grades/reports are never broken)
- `/settings/report-templates` — an optional footer note on every generated report; the report's structure itself stays fixed, per the spec's formatting rules
- `/settings/backups` — visibility into logged backup jobs, with a clear explanation that real backups run at the database/provider level
- `/students/deleted` — restore any soft-deleted student, linked from the main Students page for admins

## Stage 12 (Polish Pass) — what's included, and the project is now feature-complete

- **Mobile navigation fix** — the sidebar was desktop-only with no alternative; added a full-screen `MobileNav` drawer for small screens
- **Accessibility** — every modal closes on Escape and backdrop click with proper dialog ARIA roles; skip-to-content link; landmark roles; `prefers-reduced-motion` support
- **Loading states** — skeleton screens on the highest-traffic routes (Dashboard, Students, Subjects, Reports, Analytics)
- **Empty states** — a shared `EmptyState` component, applied to Students and Reports as the reference pattern

⚠️ Honestly flagged, not glossed over: no real browser/device QA pass was possible in this environment, a WCAG contrast check on admin-configurable brand colours hasn't been done, and a few list pages still use inline empty-state markup rather than the shared component. See `PROJECT_PROGRESS.md`'s known gaps for the full list.

## Project status

All 12 stages of the original roadmap are complete. `PROJECT_PROGRESS.md` has the full spec-compliance checklist and a running list of known gaps and suggested next steps — read it before starting any further work on this project.

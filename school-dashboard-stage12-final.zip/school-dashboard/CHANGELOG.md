# CHANGELOG.md

All notable changes to this project are recorded here, newest first. Update at the end of every session.

## [Unreleased] — Stage 12: Polish Pass (Final Stage)

### Added
- `MobileNav` — full-screen navigation drawer for small screens, triggered from a hamburger button in the topbar. Fixes a real functional gap: the sidebar has been desktop-only since Stage 3 with no mobile alternative.
- `useEscapeKey` hook — Escape-to-close wired into every modal in the app (`ConfirmDialog`, `GenerateReportDialog`, `CreateTeacherDialog`, `AcademicYearForm`, `SubjectFormDialog`), each of which also gained backdrop-click-to-close and proper `role="dialog"`/`aria-modal`/`aria-labelledby`.
- Skip-to-content link, `<main>` landmark, `aria-label`/`aria-current` on sidebar nav, `aria-haspopup`/`aria-expanded`/`role="menu"` on the user menu.
- `prefers-reduced-motion` support in `globals.css`.
- `loading.tsx` skeleton screens (Dashboard, Students list + profile, Subjects list + roster, Reports, Analytics) via `Skeleton`.
- `EmptyState` shared component, applied to Students and Reports as the reference pattern.

### Notes — what this pass does not cover
- No real browser/device QA pass was possible in this environment; responsive behaviour relies on the Tailwind patterns already used throughout rather than pixel-verified testing.
- Several other list pages still use inline empty-state markup rather than the new shared `EmptyState` component — a mechanical follow-up.
- No WCAG contrast audit of admin-configurable brand colours (Settings → School) — an unusual colour choice there could reduce readability.

## [Unreleased] — Stage 11 (Part B): Subjects, Report Templates, Backups & Deleted Students

### Added
- `/settings/subjects` + `POST /api/subjects` + `PATCH /api/subjects/[id]` — add/edit subjects, "remove" via an `isActive` toggle (no hard delete, per the no-orphaned-records rule).
- `/settings/report-templates` + `PATCH /api/settings/report-template` — an optional footer note shown on every generated report; `ReportSnapshot.footerNote` threaded through `buildReportSnapshot`/`buildEndOfYearSnapshot` and rendered in both `ReportPreview` and `ReportPdfDocument`.
- `/settings/backups` — visibility-only view of `BackupLog` rows with an explanation of the provider-level backup strategy.
- `/students/deleted` + `RestoreStudentButton` — the "Deleted students" restore UI, on top of the existing `/api/students/[id]/restore` API from Stage 4. Linked from the main Students page for admins.
- `src/lib/validation/subject.ts`.

### Notes
- Report template customisation is deliberately limited to the footer note — section order and structure are a fixed formatting rule from the spec, not exposed as configurable layout.

## [Unreleased] — Stage 11 (Part A): Settings — Nav Shell, School, Academic Year, Users

### Added
- `SettingsSubNav` + settings layout — role-aware sub-navigation (admins get the full set; teachers get only My Profile).
- `/settings/school` + `PATCH /api/settings/school` — school name, logo URL, brand colours with live swatch preview.
- `/settings/academic-year` + `POST /api/academic-years` + `PATCH /api/academic-years/[id]` — add academic years, edit term dates, set the current year (transactionally clears the previous current year).
- `/settings/users` — full UI on top of the existing Stage 2 API: create teacher accounts (with subject multi-select), view assigned subjects/last login/status, deactivate/reactivate with confirmation.
- `/settings/profile` — read-only account info for any signed-in user.
- Placeholder pages for Subjects/Report Templates/Backups (Part B).
- `src/lib/validation/settings.ts`, `src/lib/validation/academic-year.ts`.

## [Unreleased] — Stage 10: Analytics Section

### Added
- `src/lib/analytics.ts` — `getAnalyticsData()`, a single aggregation pass over the current academic year's `TermRecord`s producing grade trend, predicted-outcomes distribution, attendance (by term and year group), behaviour distribution, progress-over-time, and subject-performance data.
- Six chart components on `/analytics`: `GradeTrendChart`, `PredictedOutcomesChart`, `AttendanceCharts`, `BehaviourSummaryChart`, `ProgressOverTimeChart`, `SubjectPerformanceChart` — all Recharts, all reading real data with no separate analytics data path.

### Changed
- `/analytics` replaced its placeholder with the full chart grid.

## [Unreleased] — Stage 9: End-of-Year Report

### Added
- `buildEndOfYearSnapshot()` (`src/lib/reports.ts`) — aggregates all three terms per subject (Term 1→2→3 trend, "final" grade = latest term with data), whole-year behaviour/attendance averages, and `yearStartAverage`/`yearEndAverage`/`improvement`.
- `ReportSnapshot.type` and optional `termTrend` per subject, so one snapshot shape covers both report kinds.
- `GenerateReportDialog` — Report Type selector (Term report / End of year report); term picker only shown for term reports.
- `generateReportSchema` updated to make `term` optional (required only when type is `TERM`).

### Changed
- `ReportPreview` and `ReportPdfDocument` are now type-aware: Praise → "Strengths & Achievements", Causes for Concern → "Recurring Concerns", Targets → "Recommendations for Next Year" on end-of-year reports; Subject Breakdown shows the Term 1/2/3 trend instead of Current/Working At/Predicted. Same fixed section order and N/A fallback either way — no separate layout was invented.
- `POST /api/reports/generate` branches between `buildReportSnapshot()` and `buildEndOfYearSnapshot()` based on the requested type.
- `ReportEditForm` labels adapt to report type.

### Notes
- No schema changes required — `Report.type` and nullable `Report.term` already supported this since Stage 7.

## [Unreleased] — Stage 8: Email Delivery & Parents Section

### Added
- `src/lib/email.ts` — real email delivery via Resend; fails honestly with a clear reason if `RESEND_API_KEY` isn't configured, rather than faking success.
- `POST /api/reports/[id]/send` rewritten to render the PDF once and actually email it to every parent contact; each attempt logs its own `ReportEmailLog` row with a real `SENT`/`FAILED` status and provider message ID.
- `ReportActions` now surfaces the real per-recipient send outcome.
- `ReportEmailHistory` — shared component showing recipient/sent-by/when/status, used on both the report and parent pages.
- `/parents` — searchable contact list; `/parents/[parentId]` — contact details, linked student, ready-to-send reports for quick access, and full communication history.
- `EMAIL_FROM_DOMAIN` added to `.env.example`.

### Removed
- The Stage 7 Part B stub send logic (which recorded a send without dispatching an email) — fully replaced by real delivery.

## [Unreleased] — Stage 7 (Part B): Approve, Send & PDF Export

### Added
- `ReportPdfDocument` (`@react-pdf/renderer`) — the real downloadable PDF, mirroring `ReportPreview` exactly: same fixed section order, same `N/A` fallback, same data. Uses Helvetica for reliability; rows/sections use `wrap={false}` to avoid splitting across a page break.
- `GET /api/reports/[id]/pdf` — streams the rendered PDF.
- `POST /api/reports/[id]/approve` — locks the snapshot; further edits via `PATCH /api/reports/[id]` are rejected afterwards.
- `POST /api/reports/[id]/send` — moves status to `SENT`, creates one `ReportEmailLog` row per parent contact.
- `ReportActions` component — Approve/Send (confirmation dialogs) and View PDF, shown per report based on status and permission.

### Important note
- **Send does not dispatch a real email yet.** No provider (Resend/SMTP) is wired up until Stage 8 — this stage only builds the workflow state and history rows Stage 8 needs. Don't treat a "Sent" status as delivered until Stage 8 lands.

## [Unreleased] — Stage 7 (Part A): Report Generation, Preview & Edit

### Added
- `src/lib/reports.ts` — `buildReportSnapshot()`, assembling a frozen `ReportSnapshot` (attendance, behaviour, academic summary, subject breakdown, blank Praise/Causes for Concern/Targets) from a student's current data.
- `POST /api/reports/generate` — creates a `DRAFT` report from that snapshot.
- `PATCH /api/reports/[id]` — edits Praise/Causes for Concern/Targets, moving status to `EDITED`; rejected once `APPROVED`/`SENT`.
- `/reports` — report list with `GenerateReportDialog` (student + term picker).
- `/reports/[id]` — `ReportPreview` (fixed section order, `N/A` fallback, matching the spec exactly) and `ReportEditForm` for the three editable sections.
- `src/lib/validation/report.ts` — `generateReportSchema`, `updateReportContentSchema`.

### Not included yet (Part B)
- Approve and Send actions, the actual PDF file (`@react-pdf/renderer`), download, and delivery — the in-browser preview stands in for the PDF for now, built from the same snapshot Part B's PDF template will consume.

## [Unreleased] — Stage 6: Student Profile, Full Depth

### Added
- `ProfileTabs` — tabbed profile shell (Overview / Academic History / Progress / Attendance & Behaviour / SEN & Notes / Parents); tab content is rendered server-side, only the active-tab switch runs client-side.
- `AcademicHistoryTable` — Current/Target grade per subject across all three terms in one grid.
- `ProgressChartsPanel` (Recharts) — average-grade-over-time line chart and a per-subject grade trend chart.
- `AttendanceBehaviourPanel` (Recharts) — attendance-by-term bar chart and a per-subject Behaviour/Attitude table across all three terms.

### Changed
- `/students/[studentId]` restructured from a single long page into the tabbed layout above; all chart/table data is computed server-side from the same `TermRecord` rows the Stage 5 grade grid writes to.

## [Unreleased] — Stage 5 (Part B): Bulk Grade Entry Grid

### Added
- `BulkGradeGrid` / `GradeRow` — the editable spreadsheet-style grid replacing the Part A read-only roster table. Each row edits Current/Working At/Target grades, Behaviour, Attitude, and Comment independently, with a live Progress badge.
- `useAutosave` hook — 800ms debounce on change, plus an immediate `flush()` on blur so a save is never left pending if the browser closes right after typing.
- `AutosaveIndicator` — Saving… / Saved / Couldn't save, shown per row.
- `PATCH /api/term-records/[id]` — recalculates `differenceFromTarget` and `progressRating` server-side on every save; auto-derives `predictedGrade` from the weighted grade trend across the enrolment's terms unless an admin explicitly overrides it (`PREDICTED_GRADE_OVERRIDE`, logged as `PREDICTED_GRADE_OVERRIDDEN` vs `GRADE_UPDATED`).
- `src/lib/validation/term-record.ts` — `updateTermRecordSchema`.

### Changed
- `/subjects/[subjectId]/[yearGroup]` now renders `BulkGradeGrid` instead of a static table.

## [Unreleased] — Stage 5 (Part A): Subjects Navigation & Teacher Assignment

### Added
- `/subjects` — subject list with year-group badges and teacher counts.
- `/subjects/[subjectId]` — subject detail: `TeacherAssignmentPanel` (add/remove teachers on a subject, admin-only) and links into each applicable year group.
- `/subjects/[subjectId]/[yearGroup]` — class roster page with term tabs; access gated to admins and teachers actually linked to the subject via `TeacherSubject`. Read-only for now — the editable grid is Part B.
- `POST/DELETE /api/subjects/[subjectId]/teachers` — add/remove a teacher from a subject.
- `src/lib/validation/subject-teacher.ts`.

### Changed (design correction, per explicit instruction)
- Reverted an initial "assign one teacher per subject+year-group class" design (`assign-teacher` endpoint, now deleted) in favour of the existing `TeacherSubject` many-to-many with no year-group restriction — a teacher linked to a subject can enter grades for any year group of it, since coverage varies teacher to teacher.

## [Unreleased] — Stage 4: Students Module

### Added
- `/students` — year-group tabs, search (name/Student ID), filters (subject, SEN status, cause for concern), all server-side via URL search params.
- `/students/new` — Add Student form (personal details, SATs scores, SEN/cause for concern, dynamic parent-contact fields), admin-only.
- `/students/[studentId]` — profile page: header with Remove Student action, key stats, current-term subject grades table, parent contacts, SEN notes.
- `src/lib/students.ts` — `createStudentWithEnrolments()`: generates the Student ID, auto-enrols in every active subject for the student's year group in the current academic year, and pre-creates all three Term records per enrolment.
- `src/lib/student-id.ts` — sequential Student ID generator (`STU{year}-{0000}`).
- API routes: `POST /api/students`, `DELETE /api/students/[id]` (soft delete), `POST /api/students/[id]/restore`.
- `src/lib/validation/student.ts` — `createStudentSchema` (shared by client form and API route).
- New components: `ConfirmDialog` (shared), `YearGroupTabs`, `StudentFilters`, `StudentTable`, `AddStudentForm`, `DeleteStudentButton`, `ProfileHeader`, `SubjectGradesTable`, `ParentContactsCard`.
- `STUDENT_VIEW` added to the permissions map.

### Changed
- `Enrolment.teacherId` is now nullable (was required) — auto-enrolment happens at student-creation time, before a specific class teacher has been assigned; assignment comes with Stage 5. Run `prisma migrate dev` again after pulling this change.

## [Unreleased] — Stage 3: App Shell & Dashboards

### Added
- `Sidebar` (collapsible, active-link highlighting), `Topbar` (search + term/date + user menu), `PageHeader` reusable component.
- `GlobalSearch` — debounced student search by name/ID (`/api/search`), available to both roles.
- `UserMenu` — profile link + sign out.
- Role-aware `/dashboard` landing page: `AdminDashboard` and `TeacherDashboard`, backed by `src/lib/dashboard.ts` query functions, covering every widget from the spec's "Dashboard Improvements" section.
- `StatCard` and `ActivityFeed` reusable dashboard components.
- Placeholder pages for Students, Subjects, Reports, Parents, Settings so sidebar navigation is fully wired ahead of their real builds.
- `src/lib/academic-year.ts` — shared `getCurrentTermLabel()` / `getCurrentAcademicYear()`, deduplicated from the login page.
- `src/lib/utils.ts` — `cn()` classname helper.
- Root `/` now redirects to `/dashboard`.

### Changed
- Login's default post-authentication redirect changed from `/analytics` to `/dashboard` (Analytics is now a distinct, deeper charts section built in Stage 10; the landing dashboard is the spec's "Dashboard Improvements" widgets).
- `middleware.ts` updated to match the new default redirect target.

## [Unreleased] — Stage 2: Authentication & Permissions

### Added
- Auth.js v5 credentials-provider authentication (`src/lib/auth.ts`), JWT sessions (8-hour expiry), bcrypt password verification, generic login failure messaging (no account enumeration).
- `middleware.ts` protecting every route except `/login` and the auth API.
- `src/lib/session.ts`: `requirePermission()` / `requireUser()` — the real server-side security boundary, used by every API route; re-validates `isActive` against the DB on each call.
- `src/hooks/usePermissions.ts` — client-side convenience hook for hiding/disabling UI by role (not a security boundary on its own).
- `src/lib/password.ts` — hash/verify helpers.
- `src/lib/activity-log.ts` — `logActivity()` / `getRecentActivity()` / `getRecentActivityForUser()`, now wired into login and teacher account changes.
- Login page (`(auth)/login`) and `LoginForm` component — split-screen brand design (navy/amber, Fraunces + Inter, ruled "register" motif) rather than a generic template screen.
- Root layout (`src/app/layout.tsx`) — loads fonts via `next/font`, injects live brand colours from `SchoolSettings` as CSS variables so Settings → School (Stage 11) re-themes the app without a rebuild.
- `Providers` component wrapping `SessionProvider` and `QueryClientProvider`.
- Teacher management API foundation: `GET/POST /api/teachers`, `PATCH /api/teachers/[id]` — create, edit, deactivate, reactivate, and many-to-many subject assignment, all admin-only and fully activity-logged.
- Minimal protected `(dashboard)` layout and `/analytics` placeholder page to validate the full login → session → protected route flow (superseded by the real app shell in Stage 3).

## [Unreleased] — Stage 1: Foundation

### Added
- Initial project scaffold: Next.js 14 (App Router) + TypeScript, Tailwind CSS, shadcn/ui theming baseline.
- Prisma schema (v2) covering: `User`, `TeacherSubject`, `Subject`, `Student`, `ParentContact`, `Enrolment`, `TermRecord`, `AcademicYear`, `Report`, `ReportEmailLog`, `NoteFromTeacher`, `ActivityLog`, `SchoolSettings`, `BackupLog`.
- Seed script with one Administrator account, three sample Teacher accounts, sample subjects for Y7–9 and Y10–11, and a handful of demo students.
- `ARCHITECTURE.md`, `PROJECT_PROGRESS.md`, and this `CHANGELOG.md` created per mandatory documentation requirement.

### Changed (from the v1 plan, per approved revision request)
- User management expanded from "one teacher" assumption to full multi-teacher support with admin-managed create/edit/deactivate/reactivate.
- Teacher↔Subject relationship changed from implicit single-teacher-per-enrolment to an explicit many-to-many `TeacherSubject` join table.
- Grade model expanded from a single "current grade" field to the full 9–1 GCSE-scale set: Current, Working At, Predicted, Target, Previous, Teacher Assessment, Difference from Target.
- Report workflow expanded from "generate → preview/edit → send" to a formal state machine: Draft → Preview → Edit → Approve → Send, with `contentSnapshot` immutability after approval.
- Student deletion changed from an open question to a confirmed **soft-delete** approach (`deletedAt`), matching the recommendation made in the v1 plan.
- Added `ActivityLog` as a first-class table (previously implied via per-record audit columns only) to support the new dashboard "recent activity" requirements and full action logging.
- Added `BackupLog` table to support the new automated-backup requirement.

### Notes
- No breaking changes yet — this is the first implementation session, so there is no prior running code to migrate.

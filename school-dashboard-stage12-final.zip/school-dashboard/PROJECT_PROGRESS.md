# PROJECT_PROGRESS.md

> Read this file at the start of every session to see exactly what's done, what's in progress, and what's next. Update it at the end of every session.

## Overall roadmap status

| Stage | Description | Status |
|---|---|---|
| 1 | Foundation (project setup, schema, seed data) | ✅ Complete |
| 2 | Authentication & permissions | ✅ Complete |
| 3 | App shell (sidebar/topbar/navigation) | ✅ Complete |
| 4 | Students module | ✅ Complete |
| 5 | Subjects & bulk grade entry | ✅ Complete |
| 6 | Student profile — full depth | ✅ Complete |
| 7 | Reports engine | ✅ Complete (email delivery is Stage 8) |
| 8 | Email delivery | ✅ Complete |
| 9 | End-of-year report | ✅ Complete |
| 10 | Analytics section | ✅ Complete |
| 11 | Settings (incl. user management, backups) | ✅ Complete |
| 12 | Polish pass | ✅ Complete |

## Spec compliance checklist (living document — check off as implemented)

### User management

- [x] Admin can create/edit/deactivate/reactivate teacher accounts — API (Stage 2) plus the `/settings/users` UI (Stage 11)
- [x] Teacher record: name, email, password, active status, created date, last login, assigned subjects
- [x] Many-to-many teacher↔subject support (`TeacherSubject` join table, wired into create/update routes)
- [x] All actions logged and linked to acting user (`ActivityLog` + `logActivity()`, used by login, teacher CRUD; extended to every other module as it's built)

### Dashboards
- [x] Admin dashboard: totals, pending reports, attendance/behaviour overview, activity log, recent students, quick add, global search, current term/date
- [x] Teacher dashboard: assigned classes, students needing attention, pending grade tasks, draft reports, recent activity

### Students
- [x] Add/remove (soft delete) students — admin only
- [x] Auto-generated Student ID
- [x] Year-group organisation, search + filters (year, subject, predicted grade, cause for concern, SEN) — predicted-grade filter deferred, no predicted grades exist until Stage 5 grade entry is built
- [x] Full profile: ID, name, year group, SATs scores, predicted/current grades, attendance, behaviour, attitude, progress, SEN info, notes, parent info, academic history, interactive progress graphs — tabbed profile (Overview / Academic History / Progress / Attendance & Behaviour / SEN & Notes / Parents)
- [x] Restore soft-deleted students (admin) — `/students/deleted` lists removed students with a Restore action, on top of the `/api/students/[id]/restore` API from Stage 4

### Subjects & grading
- [x] Correct subject lists per year group (Y7–9 vs Y10–11) — set at seed time, editable via Settings in Stage 11
- [x] Three terms per subject (created automatically per enrolment, Stage 4)
- [x] Bulk grade entry (spreadsheet-style) — `/subjects/[subjectId]/[yearGroup]`, editable per-row
- [x] Autosave with no data loss on refresh/close — debounced save on change + immediate flush on blur
- [x] Grade fields: Current, Working At, Predicted, Target, Difference from Target — all 9–1 scale. `Previous Grade` and `Teacher Assessment` exist in the schema/API but aren't yet surfaced as grid columns (small UI addition, noted below)
- [x] Predicted grade auto-derived; admin-only override (`PREDICTED_GRADE_OVERRIDE` permission, enforced server-side)

### Reports
- [ ] Term-end auto-generation for every student — currently manual generation per student via `/reports`; automated batch generation is a Stage 11 candidate
- [x] End-of-year summary report — `buildEndOfYearSnapshot()` aggregates all three terms; same fixed-order layout with relabelled sections (Strengths & Achievements, Recurring Concerns, Recommendations) and a Term 1/2/3 trend table per subject
- [x] Workflow: Generate → Preview → Edit → Approve → Send — fully implemented, including locking the snapshot on approval
- [x] Fixed section order + N/A fallback + consistent branding — `ReportPreview` (in-browser) and `ReportPdfDocument` (actual PDF, `@react-pdf/renderer`) both implement the exact same structure from one shared snapshot
- [x] PDF generation with pagination — `GET /api/reports/[id]/pdf`; table rows and sections use `wrap={false}` so nothing splits awkwardly across a page break
- [x] Email delivery with full history (sent, by whom, delivery status, recipient) — real delivery via Resend (`src/lib/email.ts`); `ReportEmailLog` records each attempt with real `SENT`/`FAILED` status, visible on both the report and parent pages

### Parents
- [x] Contact info, linked students, communication/email history, quick send — `/parents` (searchable list) and `/parents/[parentId]` (contact details, linked student, approved-and-ready-to-send reports, full email history)

### Analytics
- [x] Grade trends, predicted outcomes, attendance stats, behaviour summaries, progress over time, subject performance — all six live on `/analytics`, aggregated school-wide from the same `TermRecord` data every other module reads/writes

### Settings
- [x] School name/logo/colours — `/settings/school`, live brand-colour theming already wired since Stage 2
- [x] Academic years/term dates — `/settings/academic-year`, create new years, set which is current
- [x] User management (teachers) — `/settings/users`, full UI on top of the existing API: create, view subjects/last login/status, deactivate/reactivate
- [x] Subject management (add/edit/remove, system-wide reflection) — `/settings/subjects`; "remove" is soft (isActive toggle), matching the no-hard-delete data-integrity rule
- [x] Report template settings — `/settings/report-templates`; deliberately limited to an optional footer note, since the section order/structure itself is a fixed formatting rule from the spec, not something meant to be customisable
- [x] Backup visibility — `/settings/backups`; visibility only (lists `BackupLog` rows and explains the provider-level backup strategy) — no self-service restore yet, as documented in ARCHITECTURE.md §8

### Data integrity
- [x] No orphaned records — no hard deletes anywhere (students/subjects/users are soft-deactivated); Prisma's required relations mean a Report/Enrolment/TermRecord can't exist without a valid parent
- [ ] No duplicate students — Student ID is always unique (auto-generated), but there's no check for two students with the same name/DOB being created by mistake; worth adding a "possible duplicate" warning in the Add Student flow if this becomes a real issue
- [x] Term structure (T1/T2/T3) always exists per enrolment — created automatically at enrolment time (Stage 4)
- [x] Reports always reference valid students/academic years — enforced by required foreign keys, not just application logic

### Documentation & process
- [x] ARCHITECTURE.md created
- [x] CHANGELOG.md created
- [x] PROJECT_PROGRESS.md created
- [x] Updated at end of every session going forward — all 12 stages logged

### Polish (Stage 12)
- [x] Loading states — `loading.tsx` skeleton screens for Dashboard, Students (list + profile), Subjects (list + roster), Reports, Analytics
- [x] Empty states — shared `EmptyState` component; applied to Students and Reports as the reference pattern (other list pages still use inline equivalents — see known gaps)
- [x] Accessibility — Escape-to-close and `role="dialog"`/`aria-modal` on every modal (`ConfirmDialog` and all four ad-hoc settings/report dialogs), a skip-to-content link, `<main>` landmark, `aria-label`/`aria-current` on sidebar navigation, `aria-haspopup`/`aria-expanded`/`role="menu"` on the user menu, `prefers-reduced-motion` support
- [x] Responsive — fixed a real functional gap: the sidebar was desktop-only with no mobile alternative at all; added `MobileNav`, a full-screen drawer with the same nav items, accessible from a hamburger button in the topbar on small screens
- [ ] Full breakpoint-by-breakpoint visual QA — not verified in a real browser (this environment can't run one); the responsive patterns used throughout (responsive Tailwind classes, `overflow-x-auto` on every data table) should hold up, but a real device/browser pass is still worth doing before launch

## Current session log

**Session 1:**
- Reviewed and approved v1 plan; incorporated v2 revisions (multi-teacher, dashboards, 9–1 grade fields, report workflow, backups, soft delete).
- Created mandatory documentation files.
- Began Stage 1 (Foundation): project scaffold, Prisma schema v2, seed data.

**Session 2:**
- Completed Stage 2 (Authentication & Permissions): Auth.js v5 credentials provider, protective middleware, server-side `requirePermission()` boundary, client `usePermissions()` hook, distinctive login page, brand-colour theming wired to `SchoolSettings`, and the teacher-management API foundation (`/api/teachers`, `/api/teachers/[id]`) with full activity logging.
- Added a minimal protected dashboard placeholder to prove login → session → protected route end-to-end; replaced properly in Stage 3.

**Session 3:**
- Completed Stage 3 (App shell): collapsible `Sidebar`, `Topbar` with debounced `GlobalSearch` (students by name/ID) and `UserMenu`, reusable `PageHeader`.
- Built the role-aware `/dashboard` landing page — `AdminDashboard` (totals, pending reports, attendance/behaviour overview, recently added students, quick add, recent activity) and `TeacherDashboard` (assigned classes, students needing attention, pending grade tasks, draft reports, recent activity), backed by `src/lib/dashboard.ts`.
- Added placeholder pages for Students/Subjects/Reports/Parents/Settings so every sidebar link resolves to a real (if not-yet-built) page instead of 404ing.
- Extracted `getCurrentTermLabel()` into `src/lib/academic-year.ts` (shared by login page and topbar) to avoid duplicated logic.
- Root `/` now redirects to `/dashboard`; login's default post-auth redirect updated accordingly.

**Session 4:**
- Completed Stage 4 (Students module): year-group tabs + search/filters (subject, SEN status, cause for concern) on `/students`; Add Student flow (`/students/new`) with dynamic parent-contact fields; student profile page (`/students/[studentId]`) with subject grades table, SEN/notes, parent contacts, and a Remove Student flow (soft delete, confirmation dialog).
- Added `src/lib/students.ts` — `createStudentWithEnrolments()`, which auto-generates the Student ID, auto-enrols the student in every active subject for their year group in the current academic year, and pre-creates all three (empty) Term records per enrolment, satisfying the "term structure always exists" data rule.
- Schema change: `Enrolment.teacherId` made nullable, since auto-enrolment happens before a specific class teacher is assigned to that student's set — assigning teachers to specific enrolments comes with Stage 5.
- Added `STUDENT_VIEW` to the permissions map (both roles) — the map didn't yet have a view-level permission before this module needed one.
- New shared components: `ConfirmDialog` (used for the delete flow, reusable for any future destructive action), `YearGroupTabs`, `StudentFilters`, `StudentTable`, `ProfileHeader`, `SubjectGradesTable`, `ParentContactsCard`.

**Session 5 (Stage 5, Part A):**
- Built Subjects list (`/subjects`) and subject detail (`/subjects/[subjectId]`) with a `TeacherAssignmentPanel` — add/remove teachers on a subject via the existing `TeacherSubject` many-to-many, admin-only.
- **Design correction (per explicit instruction):** rejected a rigid "one teacher per class" model. There is no per-year-group teacher assignment; any teacher linked to a subject can enter grades for any year group of it, since some teachers cover every class and others just one or two. `POST/DELETE /api/subjects/[subjectId]/teachers` implements this.
- Built the class roster page (`/subjects/[subjectId]/[yearGroup]`) — term tabs, access gated to admins or teachers actually linked to that subject, read-only roster table. This becomes the editable spreadsheet grid with autosave in Part B.
- `Enrolment.teacherId` (from Stage 4) is now documented as informational display-only, not an access-control mechanism — access is entirely via `TeacherSubject`.

**Session 5 (Stage 5, Part B):**
- Turned the roster into the real editable grid: `BulkGradeGrid` + `GradeRow`, one autosaving row per student, editable Current/Working At/Target grades, Behaviour, Attitude, and Comment, with a live Progress badge.
- `useAutosave` hook — debounces saves on change (800ms) and also flushes immediately on blur, so a save is never left hanging if the browser closes right after a field is filled in. `AutosaveIndicator` shows Saving…/Saved/Couldn't save per row.
- `PATCH /api/term-records/[id]` — the calculation engine: recomputes `differenceFromTarget` and `progressRating` server-side on every save (never trusts client math), and auto-derives `predictedGrade` from the weighted trend across this enrolment's terms (`derivePredictedGrade` from Stage 1) unless an admin explicitly overrides it, which requires `PREDICTED_GRADE_OVERRIDE` and is logged as a distinct activity type.
- Access control confirmed at the API layer too, not just the page: a teacher's `PATCH` is rejected unless they're linked to that term record's subject via `TeacherSubject`.

**Session 6:**
- Completed Stage 6 (Student profile — full depth): rebuilt `/students/[studentId]` as a tabbed profile — Overview, Academic History, Progress, Attendance & Behaviour, SEN & Notes, Parents — via a new `ProfileTabs` component (server-rendered tab content, client-side tab switching only).
- `AcademicHistoryTable` — Current/Target grade for every subject across all three terms in one grid.
- `ProgressChartsPanel` (Recharts) — average-grade-over-time line chart plus a per-subject grade trend chart, both driven by real `TermRecord` data.
- `AttendanceBehaviourPanel` (Recharts) — attendance-by-term bar chart plus a per-subject Behaviour/Attitude table across all three terms.
- All chart/table data is computed server-side in the profile page from the same `TermRecord` data the grade grid writes to — no separate data source to keep in sync.

**Session 7 (Stage 7, Part A):**
- Built the report generation pipeline: `buildReportSnapshot()` (`src/lib/reports.ts`) assembles a frozen `ReportSnapshot` from a student's current enrolments/term records/settings — attendance, behaviour, academic summary, subject breakdown, and blank Praise/Causes for Concern/Targets fields ready for teacher input.
- `POST /api/reports/generate` creates a `DRAFT` report from that snapshot; `PATCH /api/reports/[id]` lets Praise/Causes for Concern/Targets be edited (moves status to `EDITED`) — blocked once a report is `APPROVED`/`SENT`, since the snapshot is frozen at that point.
- `/reports` — list of all generated reports with a `GenerateReportDialog` (pick a student + term); `/reports/[id]` — preview (via `ReportPreview`, following the exact fixed section order from the spec with `N/A` fallbacks) plus an edit form for the three editable sections.
- This is genuinely Part A only: there's no Approve or Send button yet, and no PDF file — the in-browser preview is a faithful stand-in for what the PDF (Part B) will render from the same snapshot.

**Session 7 (Stage 7, Part B):**
- `ReportPdfDocument` — the actual downloadable PDF via `@react-pdf/renderer`, mirroring `ReportPreview` exactly (same fixed section order, same `N/A` fallback). Uses the built-in Helvetica font for reliability; `Font.register()` can swap in an exact brand font later if wanted. Table rows and sections are marked `wrap={false}` so nothing splits mid-row across a page break.
- `GET /api/reports/[id]/pdf` streams the rendered PDF for viewing/downloading.
- `POST /api/reports/[id]/approve` — locks the snapshot (`APPROVED`), after which `PATCH /api/reports/[id]` refuses edits.
- `POST /api/reports/[id]/send` — moves status to `SENT` and creates one `ReportEmailLog` row per parent contact. **Important honesty note:** no email is actually dispatched — there's no provider wired up yet. This records the workflow state and history rows Stage 8 needs; Stage 8 replaces the stub with a real send call and updates delivery status from provider webhooks.
- `ReportActions` — Approve/Send (both behind confirmation dialogs) and View PDF, shown per report based on status and permissions.

**Session 8:**
- Completed Stage 8 (Email delivery & Parents section).
- `src/lib/email.ts` — real email delivery via Resend. If `RESEND_API_KEY` isn't configured, sends fail honestly (`FAILED` status with a clear reason) rather than pretending to succeed.
- Rewrote `POST /api/reports/[id]/send` to actually render the PDF once and email it to every parent contact; each attempt gets its own `ReportEmailLog` row with a real `SENT`/`FAILED` status and the provider's message ID. Report status only moves to `SENT` if at least one email actually went out.
- `ReportActions` now shows the real per-recipient outcome after sending (e.g. "Sent to 2 of 3 — 1 failed: <reason>") instead of assuming success.
- `ReportEmailHistory` — shared table component (recipient, sent by, when, status), now shown on both the report detail page and the parent detail page.
- `/parents` — searchable list of parent contacts with linked student and relationship; `/parents/[parentId]` — contact details, linked student link, any of their child's approved-and-ready-to-send reports (the "quick send" access point from the spec), and full communication history.

**Session 9:**
- Completed Stage 9 (End-of-year report). Rather than inventing a separate layout, the end-of-year report reuses the exact same fixed section order and components (`ReportPreview`, `ReportPdfDocument`) as term reports, with the labels and subject table adapting via `snapshot.type`:
  - Praise → **Strengths & Achievements**, Causes for Concern → **Recurring Concerns**, Targets → **Recommendations for Next Year**
  - Subject Breakdown shows the Term 1 → Term 2 → Term 3 grade trend per subject instead of Current/Working At/Predicted
  - Overall Academic Summary adds a year-progress line (start average → end average, with the improvement)
- `buildEndOfYearSnapshot()` (`src/lib/reports.ts`) aggregates across all three terms: each subject's "final" grade is the latest term with data, behaviour/attendance are averaged across the whole year, and `yearStartAverage`/`yearEndAverage`/`improvement` are computed for the summary.
- `GenerateReportDialog` now has a Report Type selector (Term report / End of year report); the term picker only shows for term reports.
- No schema changes needed — `Report.type` and nullable `Report.term` already supported this from Stage 7.

**Session 10:**
- Completed Stage 10 (Analytics section). `getAnalyticsData()` (`src/lib/analytics.ts`) fetches every `TermRecord` in the current academic year once and aggregates in JS (grouping by a joined table's field like `student.yearGroup` isn't something Prisma's `groupBy` can do directly, and this is simpler and fast enough at a single school's data volume).
- Six chart widgets on `/analytics`, all reading the same underlying data every other module writes to: Grade trend over time, Predicted GCSE outcomes (Y10/11 only), Attendance (by term and by year group), Behaviour summary, Progress over time (stacked Above/On/Below), Subject performance.
- "Latest term with data per enrolment" logic (used for predicted outcomes, behaviour, subject performance) is implemented independently here rather than reusing Stage 9's similar end-of-year logic, since this one operates school-wide rather than per-student — flagged below as a small future refactor.

**Session 11 (Stage 11, Part A):**
- Settings navigation shell (`SettingsSubNav` + layout) — role-aware: admins see School/Academic Year/Users/Subjects/Report Templates/Backups/My Profile; teachers see only My Profile, matching "reduced subset" from the spec.
- `/settings/school` — school name, logo URL, and brand colour pickers with a live swatch preview, saving to the same `SchoolSettings` singleton the whole app already reads for theming (Stage 2).
- `/settings/academic-year` — list of academic years with term dates, a dialog to add a new one, and a "Set as current" action (transactionally unsets the previous current year first, so there's always exactly one).
- `/settings/users` — the UI the Stage 2 API was always meant to get: create teacher accounts (with subject multi-select), see their assigned subjects/last login/status at a glance, and deactivate/reactivate with a confirmation dialog.
- `/settings/profile` — simple read-only account info page (name, email, role, last login) for both roles; account edits are admin-only via Users.
- Added placeholder pages for Subjects/Report Templates/Backups (Part B) so the settings sub-nav doesn't 404.

**Session 11 (Stage 11, Part B):**
- `/settings/subjects` — add subjects (name, code, applicable year groups), edit them, and "remove" via an isActive toggle rather than a hard delete — matching the no-orphaned-records data rule, since a real delete would break historical grades/reports referencing that subject.
- `/settings/report-templates` — a single optional footer note, shown at the bottom of every generated report (term and end-of-year), stored in `SchoolSettings.reportTemplateConfig`. Deliberately limited in scope: the report's section order and structure are a fixed formatting rule from the spec, not something meant to be customisable, so this doesn't expose layout controls.
- `/settings/backups` — visibility only, per ARCHITECTURE.md §8: lists `BackupLog` rows (likely empty, since no scheduled job writes to it yet) and clearly explains that real backups are handled at the database/provider level, not by a button on this page.
- `/students/deleted` — the "Deleted students" restore UI flagged as a known gap since Stage 4; lists soft-deleted students with a Restore action on top of the existing API, linked from the main Students page for admins.

**Session 12 (Stage 12 — Polish pass, final stage):**
- **Mobile navigation fix (functional, not just visual):** the sidebar has been desktop-only (`hidden md:flex`) since Stage 3, with no alternative — phone/tablet users had no way to navigate at all. Added `MobileNav`, a full-screen drawer triggered from a hamburger button in the topbar on small screens, sharing the same `NAV_ITEMS` as the desktop sidebar.
- **Accessibility:** every modal in the app (`ConfirmDialog`, `GenerateReportDialog`, `CreateTeacherDialog`, `AcademicYearForm`, `SubjectFormDialog`) now closes on Escape (`useEscapeKey` hook) and on backdrop click, and has proper `role="dialog"` / `aria-modal` / `aria-labelledby`. Added a skip-to-content link, a `<main>` landmark, `aria-label`/`aria-current` on sidebar navigation, and `aria-haspopup`/`aria-expanded`/`role="menu"` on the user menu. Added `prefers-reduced-motion` support so the fade/slide animations don't run for users who've asked for reduced motion.
- **Loading states:** added `loading.tsx` skeleton screens (Next.js's built-in Suspense mechanism) for Dashboard, Students (list + profile), Subjects (list + roster), Reports, and Analytics — the highest-traffic, most data-heavy routes.
- **Empty states:** extracted a shared `EmptyState` component and applied it to Students and Reports as the reference pattern.
- **What this pass does NOT cover (said plainly rather than glossed over):** a real browser/device QA pass wasn't possible in this environment (no way to actually run the dev server here), so responsive behaviour is based on the Tailwind patterns used throughout (responsive classes, `overflow-x-auto` on data tables) rather than verified pixel-by-pixel; several other list pages (Subjects, Parents, Analytics's "no year configured" message) still use inline empty-state markup rather than the new shared component — mechanical follow-up, not a design question; and this pass didn't do a from-scratch WCAG contrast audit of the custom brand colours an admin might set in Settings → School (a very dark-on-dark or light-on-light choice there could reduce readability — worth a contrast check if a school picks unusual brand colours).

## Known gaps / things to revisit next session
- No duplicate-student detection — Student ID is always unique, but nothing warns if two students are created with the same name/DOB by mistake.
- Password reset is admin-only (no self-service "forgot password" email flow yet) — could reuse `src/lib/email.ts` now that real email sending exists; not built yet.
- Global search currently only searches students; extending to parents/reports can be added cheaply once needed.
- Dashboard "students needing attention" logic currently flags `causeForConcern` or a below-target most-recent term record — worth revisiting once real attendance-based flags are wanted too.
- Predicted-grade student filter on `/students` still isn't wired in — small, cheap addition, worth doing whenever convenient.
- `Previous Grade` and `Teacher Assessment` (free-text) exist as `TermRecord` fields and are accepted by the save API, but still aren't columns in the bulk grade grid or shown on the report — worth a dedicated per-student grade detail panel rather than more grid/report columns.
- Predicted-grade derivation currently uses a simple attitude-based adjustment (`CAUSE_FOR_CONCERN` → -1, else 0) as the "teacher assessment" input factor — flagged in Stage 1 as a first-pass approach; worth revisiting once there's real multi-term data to validate the weighting against.
- Reports currently have no restriction on which teacher can generate/approve/send a report for which student — matches the permissive design used elsewhere, but worth confirming this is the behaviour you want now that Send actually emails parents.
- No regenerate/history-across-terms view yet on the Reports list (e.g. "all of this student's past reports grouped together") — candidate for Part B polish or later.
- PDF uses the built-in Helvetica font rather than a custom brand font, to avoid a network font-fetch dependency at render time — swap in via `Font.register()` in `ReportPdfDocument.tsx` if exact brand-font matching matters.
- Progress/Attendance charts on the student profile (Stage 6) and school-wide Analytics (Stage 10) only cover the current academic year (we only have one seeded); once a second academic year exists, consider whether charts should span years or stay year-scoped.
- Email delivery is currently "fire and check the immediate API response" only — Resend's own delivery/bounce webhooks aren't wired up, so a `SENT` status means "accepted by Resend," not "confirmed opened/delivered." Wiring a webhook to update to `DELIVERED`/`BOUNCED` is a good future enhancement if that level of tracking matters.
- The email's `from` address is built from `EMAIL_FROM_DOMAIN` in `.env` — that domain needs to be verified in Resend before real sends will work; worth double-checking this is set up before relying on it for real parent communication.
- Term-end auto-generation (batch-generating every student's report automatically at term end) isn't built yet — currently every report (term or end-of-year) is generated one at a time via the dialog; a good background-job candidate given Inngest is already in the stack.
- End-of-year "final grade per subject" currently falls back Term 3 → Term 2 → Term 1 (latest term with data). If a school enters data out of order this could pick an earlier term than intended — worth a sanity check once real multi-term data exists.
- Analytics' "latest term with data per enrolment" logic (predicted outcomes, behaviour, subject performance) duplicates the concept from Stage 9's end-of-year logic rather than sharing a helper — small refactor candidate if a third consumer needs the same pattern.
